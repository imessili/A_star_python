## Exercice 2 - Recherche d'un chemin sur une grille

import numpy as np
import math 

def lecture_instance(nom_fichier):
	try:
		## ouverture d'une instance
		f = open("Instances/" + nom_fichier, "r")
		grille = {}
		buts = []

		## nb lingnes et colonnes
		nb_lig = int(f.readline())
		nb_col = int(f.readline())

		## le 0 est une case vide ou le robot peut aller,
        ## le 1 est un mur et represente donc une case ou le robot ne peut pas aller,
        ## le 2 represente un etat but
        ## lire chaque ligne de la matrice et la mettre dans le dict grille
        ## trouver les but est les mettre dans la liste buts
		for i in range(nb_lig):
			grille[i] = []
			line = f.readline()
			line = line.split(" ")
			for j in range(nb_col):
				grille[i].append(int(line[j]))
				if grille[i][j] == 2:
					buts.append((i, j))

	    ## fermeture de fichier instance
		f.close()
		return grille, buts
	## En cas le fichier instance n'existe pas
	except FileNotFoundError:
		print("File not found")
		return 1, 1


if __name__ == '__main__':
    grille, buts = lecture_instance("instance1.txt")
    print("grille : ", grille)
    print("buts : ", buts)
	# chemin, cout = a_star(grille, len(grille), len(grille[0]), buts)
	# print(cout, chemin)	

## Fonction qui calcule l'heuristique de Manhattan
## Decommenter l'heuristique nulle ou Euclidean pour tester
def calcul_heuristique_manhatan(lin_case,col_case,lin_but,col_but):
    ## heuristique nulle / 0
	## h = 0

	##  heuristique supplementaire / Euclidean 
	## h = math.sqrt(math.pow(lin_but - lin_case, 2) + math.pow(col_but - col_case, 2))

	## heuristique proposee / Manhattan
	h = abs(lin_but - lin_case) + abs(col_but - col_case)

	return h

## Fonction qui recupere les cases adjacents et leur cout
def case_adjacents(lin, col):
    case_adj = []

    ###### cout == 1
    if lin + 1 < len(grille) and grille[lin + 1][col] in {0,2}:
        case_adj.append((lin + 1, col, 1))

    if col + 1 < len(grille[0]) and grille[lin][col + 1] in {0,2}:
        case_adj.append((lin, col + 1, 1))

    if lin - 1 >= 0 and grille[lin - 1][col] in {0,2}:
        case_adj.append((lin - 1, col, 1))

    if col - 1 >= 0 and grille[lin][col - 1] in {0,2}:
        case_adj.append((lin, col - 1, 1))
        
    ###### cout == 1.5
    if lin + 1 < len(grille) and col + 1 < len(grille[0]) and grille[lin + 1][col + 1] in {0,2}:
        case_adj.append((lin + 1, col + 1, 1.5))

    if lin - 1 >= 0 and col - 1 >= 0 and grille[lin - 1][col - 1] in {0,2}:
        case_adj.append((lin - 1, col - 1, 1.5))

    if lin - 1 >= 0 and col + 1 < len(grille[0]) and grille[lin - 1][col + 1] in {0,2}:
        case_adj.append((lin - 1, col + 1, 1.5))

    if lin + 1 < len(grille) and col - 1 >= 0 and grille[lin + 1][col - 1] in {0,2}:
        case_adj.append((lin + 1, col - 1, 1.5))
    

    return case_adj

## Insertion dans des cases adjacents dans la liste des cases ouverts
def insertion(cases_ouverts, z, g, h):
 
    if len(cases_ouverts) == 0 :
        cases_ouverts.append(z)
    else:
        for case in cases_ouverts:
            if g.get(z) + h.get(z) < g.get(case) + h.get(case) :
                cases_ouverts.insert(cases_ouverts.index(case),z)
                break
            if g.get(z) + h.get(z) == g.get(case) + h.get(case) :
                if h.get(z) < h.get(case):
                    cases_ouverts.insert(cases_ouverts.index(case),z)
                    break
                else:
                    cases_ouverts.insert(cases_ouverts.index(case)+1,z)
                    break
        if z not in cases_ouverts:
            cases_ouverts.append(z)

## Reconstruire le chemin a partir des predecesseur
## La liste chemin est vide si ils y a pas de chemin
def trouver_chemin(buts, pred):
    chemin = []
    if None in pred and pred[None] in buts:
        current_elm = pred[None]
        chemin.append(current_elm)
        while current_elm != None:
            current_elm = pred[current_elm]
            chemin.append(current_elm)
        chemin.remove(None) 
        
    return chemin

## Definition de l'algorithme A*
def a_star(depart, buts):

    d = depart
    cases_ouverts = [d] 
    cases_fermes = []

    but_min_cout = (buts[0])
    h_debut = calcul_heuristique_manhatan(d[0],d[1],but_min_cout[0],but_min_cout[1])
    
    for but in buts:
        if h_debut < calcul_heuristique_manhatan(d[0],d[1],but[0],but[1]):
            h_debut = calcul_heuristique_manhatan(d[0],d[1],but[0],but[1])
            but_min_cout = but
            
    h = {d: h_debut}
    g = {d: 0.0} 
    pred = {d: None}
    
    while cases_ouverts: 
        c = cases_ouverts[0]
        cases_ouverts.remove(c)  
        cases_fermes.append(c)
        if c != but_min_cout:
            for z in case_adjacents(c[0], c[1]):
                case_z = (z[0],z[1])
                cout_z = z[2]
                
                if case_z not in cases_fermes:
                    if case_z not in cases_ouverts:
                        pred[case_z] = c
                        h[case_z] = calcul_heuristique_manhatan(case_z[0],case_z[1],but[0],but[1])
                        g[case_z] = g[c] + cout_z
                        insertion(cases_ouverts, case_z, g, h)
                    else:
                        g[case_z] = min(g[case_z], g[c] + cout_z ) 
        else:
            pred[None] = c
            break
            
    chemin_optimal = trouver_chemin(buts, pred)
    
    if len(chemin_optimal) != 0:
        print("Le chemin optimal est : ", chemin_optimal)
        print("Le cout de chemin optimal est : ", g[but_min_cout])
        print ("Le nombre de noueds cree est : ", len(h))
    else:
        print("Pas de chemin optimal")
        
## Lancer l'algorithme A*
a_star((0,0), buts)