## Exercice 1 - Implementation de l'exploration A* sur un graphe simple

from re import S
import numpy as np

"""
# Données de autre exemple
nb_sommets = 6
sommets = {i for i in range(nb_sommets)}
buts = {5}
arcs = {0: [1, 5], 1: [2, 3], 2: [4], 3: [4,5], 4: [5], 5: []}
couts = {(0, 1): 1, (0, 5): 10, (1, 2): 2, (1, 3): 1, (2, 4): 5, (3, 4): 3, (3, 5): 4, (4, 5):2}
h1 = {0:5, 1: 3, 2: 4, 3: 2, 4: 6, 5: 0} 

"""

"""
# Données de l'exercice de cours
nb_sommets = 11
sommets = {i for i in range(nb_sommets)}
buts = {8, 10}
arcs = {0: [1, 2], 1: [3, 4], 2: [5], 3: [6], 4: [5], 5: [7], 6: [9], 7: [8, 9], 8: [], 9: [10], 10: []}
couts = {(0, 1): 1, (0, 2): 1, (1, 3): 1, (1, 4): 1, (2, 5): 1, (3, 6): 1, (4, 5): 1, (5, 7): 1, (6, 9): 1, (7, 8): 1, (7, 9): 1, (9, 10): 1}
h1 = {1: 2, 2: 3, 3: 2, 4: 2, 5: 1, 6: 2, 7: 3, 8: 0, 9: 2, 10: 0}

"""

# Données de l'exemple
nb_sommets = 11
sommets = {i for i in range(nb_sommets)}
buts = {8, 10}
arcs = {0: [1, 2], 1: [3, 4], 2: [5], 3: [6], 4: [5], 5: [7], 6: [9], 7: [8, 9], 8: [], 9: [10], 10: []}
couts = {(0, 1): 1, (0, 2): 3, (1, 3): 3, (1, 4): 2, (2, 5): 2, (3, 6): 2, (4, 5): 1, (5, 7): 1, (6, 9): 2, (7, 8): 1, (7, 9): 4, (9, 10): 3}
h1 = {1: 2, 2: 3, 3: 2, 4: 2, 5: 2, 6: 2, 7: 1, 8: 0, 9: 2, 10: 0}

def insertion(sommets_ouverts, z, g, h):
    """
    Insertion d'un sommet dans la liste des ouverts dans l'ordre croissant des valeurs (g+h)
    et en cas d'égalité dans l'ordre croissant des valeurs de h
    """
    if len(sommets_ouverts) == 0 :
        sommets_ouverts.append(z)
    else:
        for sommet in sommets_ouverts:
            if g.get(z) + h.get(z) < g.get(sommet) + h.get(sommet) :
                sommets_ouverts.insert(sommets_ouverts.index(sommet),z)
                break
            if g.get(z) + h.get(z) == g.get(sommet) + h.get(sommet) :
                if h.get(z) < h.get(sommet):
                    sommets_ouverts.insert(sommets_ouverts.index(sommet),z)
                    break
                else:
                    sommets_ouverts.insert(sommets_ouverts.index(sommet)+1,z)
                    break
        if z not in sommets_ouverts:
            sommets_ouverts.append(z)

def successeurs(sommet):
    ##Retourne la liste des successeurs d'un sommet donné en paramètre
    return arcs[sommet]

def trouver_chemin(buts, parents):
    """
    Reconstruit le chemin emprunté pour atteidre le sommet "but" à partir d'un dictionnaire contenant le parent
    de chaque sommet ouvert pendant l'algorithme
    """
    ## {0: None, 1: 0, 2: 0, 3: 1, 4: 1, 5: 4, 6: 3, 7: 5, 8: 7, 9: 7, None: 8}
    if parents[None] in buts:
        chemin = set()
        current_elm = parents[None]
        chemin.add(current_elm)
        while current_elm != None:
            current_elm = parents[current_elm]
            chemin.add(current_elm)
    chemin.remove(None) 
    return chemin

def a_star(depart, buts, h):

    s = depart
    sommets_ouverts = [s] 
    sommets_fermes = []
    g = {s: 0} 
    parents = {s: None}
    
    while sommets_ouverts: 

        s = sommets_ouverts[0]
        sommets_ouverts.remove(s)  
        
        if s not in buts:
            for z in successeurs(s):
                parents[z] = s
                if z not in sommets_fermes:
                    if z not in sommets_ouverts:
                        g[z] = g[s] + couts[s,z]
                        insertion(sommets_ouverts, z, g, h1)
                    else:
                        g[z] = min(g[z],g[s] + couts[s,z])
            sommets_fermes.append(s)
        else:
            parents[None] = s
            break
    
    chemin_optimal = trouver_chemin(buts, parents)
    
    return chemin_optimal

def cout_chemin(chemin):
    
    c_chemin = list(chemin)
    i = 0
    cout = 0
    while i < len(c_chemin) - 1:
        cout = cout + couts[(c_chemin[i],c_chemin[i+1])]
        i = i + 1
        
    return cout

chemin = a_star(0, buts, h1)
print("Chemin Optimal est:",chemin,"==>", len(chemin)-1)
print("Le cout de chemin optimal est:",cout_chemin(chemin))
