NOM : MESSILI
Prenom :Islem
Numero Etudiant : 22303045
Master 1 Informatique

Le fichier a_star_graph.py contient la 2eme version de script demander en Exercice 1
Le fichier a_star_grille_etu.py contient le script demander en  Exercice 2

Question 2:

- La structure de données que j'ai adaptée au calcul et au stockage des informations est:
   Le dictionnaire(dict)

- Une heuristique monotone pour estimer la valeur du plus court chemin entre un sommet et un sommet but est : 
   L'heuristique de manhattan

Question 3: 

- Les resultat obtinue pour les 5 instances fournies:
  
  - Instances 1 ==> cout de chemin optimal est :  17.5

  - Instances 2 ==> cout de chemin optimal est :  17.5

  - Instances 3 ==> cout de chemin optimal est :  75.5

  - Instances 4 ==> cout de chemin optimal est :  40.5

  - Instances 5 ==> Pas de chemin optimal

Question 6:

- Heuristique nulle :

  - Instances 1 ==> cout de chemin optimal est :  17.5  ,Nombre total de noeuds cree: 82

  - Instances 2 ==> cout de chemin optimal est :  17.5  ,Nombre total de noeuds cree: 82

  - Instances 3 ==> cout de chemin optimal est :  75.5  ,Nombre total de noeuds cree: 317

  - Instances 4 ==> cout de chemin optimal est :  40.5  ,Nombre total de noeuds cree: 273

  - Instances 5 ==> Pas de chemin optimal


- heuristique proposée manhattan :

  - Instances 1 ==> cout de chemin optimal est :  17.5  ,Nombre total de noeuds cree: 57

  - Instances 2 ==> cout de chemin optimal est :  14.0  ,Nombre total de noeuds cree: 44

  - Instances 3 ==> cout de chemin optimal est :  75.5  ,Nombre total de noeuds cree: 317

  - Instances 4 ==> cout de chemin optimal est :  75.5  ,Nombre total de noeuds cree: 317

  - Instances 5 ==> Pas de chemin optimal


- une heuristique supplémentaire euclidienne :


  - Instances 1 ==> cout de chemin optimal est :  17.5  ,Nombre total de noeuds cree: 17.5

  - Instances 2 ==> cout de chemin optimal est :  14  ,Nombre total de noeuds cree: 48

  - Instances 3 ==> cout de chemin optimal est :  75.5  ,Nombre total de noeuds cree: 317

  - Instances 4 ==> cout de chemin optimal est :  40.5  ,Nombre total de noeuds cree: 290

  - Instances 5 ==> Pas de chemin optimal
